//
//  AGSettingViewControllerTableViewController.h
//  UITableView Static Cells (Lesson 29)
//
//  Created by Anton Gorlov on 09.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGSettingViewControllerTableViewController : UITableViewController <UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *loginField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (weak, nonatomic) IBOutlet UISegmentedControl *levelControl;
@property (weak, nonatomic) IBOutlet UISegmentedControl *detalizationControl;
@property (weak, nonatomic) IBOutlet UISwitch *shadowsSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *vibrationSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *autoOrientationSwitch;
@property (weak, nonatomic) IBOutlet UISlider *soundSlider;
@property (weak, nonatomic) IBOutlet UISlider *musicSlider;


//Сделаем,чтобы по какому-то изменению любого из тих элементов мне будет приходить сообщение,что это изменено
- (IBAction)actionTextChanged:(UITextField *)sender;//соз с помощью перетягивания (loginField и passwordField)(Event - "Editing Changed")
- (IBAction)actionValueChanged:(id)sender;// перетянем (levelControl и т.д) (Event - "Value Changed")

@end
