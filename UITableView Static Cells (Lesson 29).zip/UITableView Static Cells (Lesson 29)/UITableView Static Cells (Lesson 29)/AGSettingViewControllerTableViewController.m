//
//  AGSettingViewControllerTableViewController.m
//  UITableView Static Cells (Lesson 29)
//
//  Created by Anton Gorlov on 09.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGSettingViewControllerTableViewController.h"

@interface AGSettingViewControllerTableViewController ()

@end

//сохраним ключи,чтобы могли сохранять наши значения и потом их считывать

static NSString* keySettingLogin        = @"login";
static NSString* keySettingPassword     = @"password";
static NSString* keySettingLevel        = @"level";
static NSString* keySettingShadows      = @"shadows";
static NSString* keySettingDetalization = @"detalization";
static NSString* keySettingSound        = @"sound";
static NSString* keySettingMusic        = @"music";



@implementation AGSettingViewControllerTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self loadSetting]; //загружаем настройки,когда запускается приложение
    
    
    [self.loginField becomeFirstResponder]; //появление клавы при запуске приложения
    self.tableView.contentInset = UIEdgeInsetsMake(20, 0, 0, 0); //отступ надписей от статус бара
    
    
}

#pragma mark- Save and Load

- (void) saveSetting { //сохраняем наши настройки (controls)
    
    //userDefoults -это класс,позволяющий сохранять не большие значения

    NSUserDefaults* userDefoults = [NSUserDefaults standardUserDefaults];
    
    [userDefoults setObject:self.loginField.text forKey:keySettingLogin];
    [userDefoults setObject:self.passwordField.text forKey:keySettingPassword];
    
    [userDefoults setInteger:self.levelControl.selectedSegmentIndex forKey:keySettingLevel];
    [userDefoults setBool:self.shadowsSwitch.isOn forKey:keySettingShadows];
    [userDefoults setInteger:self.detalizationControl.selectedSegmentIndex forKey:keySettingDetalization];
    [userDefoults setDouble:self.soundSlider.value forKey:keySettingSound];
    [userDefoults setDouble:self.musicSlider.value forKey:keySettingMusic];
    
    [userDefoults synchronize]; //если не ставить эту строку,то наши изменения будут сохранены,когда выйдем с App ,но если App упадет,то они сохранены не будуте
}

- (void) loadSetting { //загружаем наши настройки
    
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    
    self.loginField.text = [userDefaults objectForKey:keySettingLogin];
    self.passwordField.text = [userDefaults objectForKey:keySettingPassword];
    
    self.levelControl.selectedSegmentIndex = [userDefaults integerForKey:keySettingLevel];
    self.shadowsSwitch.on = [userDefaults boolForKey:keySettingShadows];
    self.detalizationControl.selectedSegmentIndex = [userDefaults integerForKey:keySettingDetalization];
    
    self.soundSlider.value = [userDefaults doubleForKey:keySettingSound];
    self.musicSlider.value = [userDefaults doubleForKey:keySettingMusic];
    
    



}
#pragma mark- UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    
    if ([textField isEqual:self.loginField]) {
        
        [self.passwordField becomeFirstResponder];
        
    }else {
        [textField resignFirstResponder];
    
    }
    return NO;
}

#pragma mark- Action
- (IBAction)actionTextChanged:(UITextField *)sender {
    
    [self saveSetting]; //сохр когда изменяются поля ввода
}

- (IBAction)actionValueChanged:(id)sender {
    
    [self saveSetting];//сохр когда изменяются наши Controls
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
