//
//  AppDelegate.h
//  UITableView Static Cells (Lesson 29)
//
//  Created by Anton Gorlov on 09.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

