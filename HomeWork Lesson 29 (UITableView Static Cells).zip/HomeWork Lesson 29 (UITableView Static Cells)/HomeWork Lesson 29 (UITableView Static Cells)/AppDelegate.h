//
//  AppDelegate.h
//  HomeWork Lesson 29 (UITableView Static Cells)
//
//  Created by Anton Gorlov on 11.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

