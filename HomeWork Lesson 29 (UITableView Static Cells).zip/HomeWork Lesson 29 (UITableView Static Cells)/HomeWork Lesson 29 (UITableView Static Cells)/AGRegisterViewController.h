//
//  AGRegisterViewController.h
//  HomeWork Lesson 29 (UITableView Static Cells)
//
//  Created by Anton Gorlov on 11.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AGRegisterViewController : UITableViewController <UITextFieldDelegate>

//For "Client info"
@property (weak, nonatomic) IBOutlet UITextField *firstNameField;
@property (weak, nonatomic) IBOutlet UITextField *lastNameField;
@property (weak, nonatomic) IBOutlet UITextField *loginField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (weak, nonatomic) IBOutlet UITextField *ageField;
@property (weak, nonatomic) IBOutlet UITextField *phoneField;
@property (weak, nonatomic) IBOutlet UITextField *emailField;

@property (assign, nonatomic) BOOL atPresent;

@property (weak, nonatomic) IBOutlet UILabel *firstNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *lastNameLabel;
@property (weak, nonatomic) IBOutlet UILabel *loginLabel;
@property (weak, nonatomic) IBOutlet UILabel *passwordLabel;
@property (weak, nonatomic) IBOutlet UILabel *ageLabel;
@property (weak, nonatomic) IBOutlet UILabel *phoneLabel;
@property (weak, nonatomic) IBOutlet UILabel *emailLabel;


@property (strong, nonatomic) IBOutletCollection(UITextField) NSArray *clientInfoTextField;
@property (strong, nonatomic) IBOutletCollection(UILabel) NSArray *clientInfoCollectionLabel;

//For "Interface"
@property (weak, nonatomic) IBOutlet UISegmentedControl *greficsSegmentedControl;
@property (weak, nonatomic) IBOutlet UISegmentedControl *backgroundSegmentedControl;

@property (weak, nonatomic) IBOutlet UISwitch *musicSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *autoSaveSwitch;
@property (weak, nonatomic) IBOutlet UISlider *volumeSlider;
@property (weak, nonatomic) IBOutlet UILabel *volumeLabel;



- (IBAction)actionMusic:(UISwitch *)sender;
- (IBAction)actionAutosave:(UISwitch *)sender;
- (IBAction)actionVolume:(UISlider *)sender;
- (IBAction)actionGrefics:(UISegmentedControl *)sender;
- (IBAction)actionBackground:(UISegmentedControl *)sender;

//for save and load with "Event" (Editing changed)

- (IBAction)actionTextFieldChanged:(UITextField *)sender;

- (IBAction)actionValueChanged:(id)sender;


@end
