//
//  AGRegisterViewController.m
//  HomeWork Lesson 29 (UITableView Static Cells)
//
//  Created by Anton Gorlov on 11.03.16.
//  Copyright © 2016 Anton Gorlov. All rights reserved.
//

#import "AGRegisterViewController.h"

@interface AGRegisterViewController ()

@end

typedef enum {
    
    AGTextFieldName,
    AGTextFieldLastName,
    AGTextFieldLogin,
    AGTextFieldPassword,
    AGTextFieldAge,
    AGTextFieldPhoneNumber,
    AGTextFieldEmail,

}AGTextField;

//список для actionGrefics (SegmentedControl)

typedef enum {
    
    AGActionGreficsSegmentedControlLow,
    AGActionGreficsSegmentedControlMiddle,
    AGActionGreficsSegmentedControlHigh,

}AGActionGreficsSegmentedControl;


//список для actionBackground (SegmentedControl)

typedef enum {
    
    AGActionBackgroundSegmentedControlBlack,
    AGActionBackgroundSegmentedControlWhite,
    AGActionBackgroundSegmentedControlGray,
    AGActionBackgroundSegmentedControlYellow,

}AGActionBackgroundSegmentedControl;


//соз ключи,чтобы могли сохранять наши значения и потом их считывать
static NSString* keyClientName          = @"name";
static NSString* keyClientLastName      = @"lastName";
static NSString* keyClientLogin         = @"login";
static NSString* keyClientPassword      = @"password";
static NSString* keyClientAge           = @"age";
static NSString* keyClientPhone         = @"phone";
static NSString* keyClientEmail         = @"email";

static NSString* keyInterfaceGrefics    = @"grefics";
static NSString* keyInterfaceMusic      = @"music";
static NSString* keyInterfaceVolume     = @"volume";
static NSString* keyInterfaceAutosave   = @"autosave";
static NSString* keyInterfaceBackground = @"background";



@implementation AGRegisterViewController





/*
 
 Итак, мы начали мою любимую тему о UITableView. Это очень важная тема, поэтому практиковаться очень важно. Заодно нужно добить контролы.
 
 Задание:
 
 Ученик-Студент-Мастер-Супермен:
 
 1. Сделайте задания из уроков 27 и 28 используя статические ячейки.
 2. Добавьте возможность сохранять результат.
 3. Добавьте новые секции и ячейки с прочим контролами (свичи, сегменты, слайдеры) чтобы проработать материал
 
 Это все
*/
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    self.tableView.contentInset = UIEdgeInsetsMake(20, 0, 0, 0);
    [self.firstNameField becomeFirstResponder];
    
    [self loadSetting];
    
    
}


#pragma mark- UITextFieldDelegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField{ // при нажатии кнопки "Return" курсор идет в след. поле.
/*
    //1-й способ
    if ([textField isEqual:self.firstNameField]) {
        [self.lastNameField becomeFirstResponder];
    }
    if ([textField isEqual:self.lastNameField]) {
        [self.loginField becomeFirstResponder];
        
    }
    if ([textField isEqual:self.loginField]) {
        [self.passwordField becomeFirstResponder];
    }
    if ([textField isEqual:self.passwordField]) {
        [self.ageField becomeFirstResponder];
    }
    if ([textField isEqual:self.ageField]) {
        [self.phoneField becomeFirstResponder];
    }
    if ([textField isEqual:self.phoneField]) {
        [self.emailField becomeFirstResponder];
    
    }else {
        [self.emailField resignFirstResponder];
    }
    
    //2-й способ
*/
    
    for (int i = 0; i < ([self.clientInfoTextField count]-1); i++) {
        
        if (!([textField isEqual:[self.clientInfoTextField objectAtIndex:i]])) {
            
            [textField resignFirstResponder];
            
        } else {
        
            [[self.clientInfoTextField objectAtIndex:i+1 ] becomeFirstResponder];
        }
    }
    


    return NO;
}


- (BOOL)textFieldShouldClear:(UITextField *)textField { // при очистке поля (textField) удаляеться и label.
    
    for (UILabel* label in self.clientInfoCollectionLabel) {
        
        if (textField.tag == label.tag) {
            
             label.text = nil;
           // label.text = @"Enter"; //во всех Лайб надпись "Enter"
        }
        if ( label.text == nil) {
            label.text = @"Empty";
        }
        
    }
    return YES;
}


- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    NSString* resultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    //берем строку,которая находиться в textField
    
    switch (textField.tag) {
            
        case AGTextFieldName:
            [self scriptNameField:textField shouldChangeCharactersInRange:range replacementString:string];
            self.firstNameLabel.text = resultString;
            
            return NO;
            break;
            
        case AGTextFieldLastName:
            [self scriptLastNameField:textField shouldChangeCharactersInRange:range replacementString:string];
            self.lastNameLabel.text = resultString;
            
            return NO;
            break;
            
        case AGTextFieldLogin:
            self.loginLabel.text = resultString;
            break;
            
        case AGTextFieldPassword:
            self.passwordLabel.text = resultString;
            break;
            
        case AGTextFieldAge:
            [self scriptAgeField:textField shouldChangeCharactersInRange:range replacementString:string];
            self.ageLabel.text = resultString;
            
            return NO;
            break;
            
        case AGTextFieldPhoneNumber:
            [self scriptPhoneNumberField:textField shouldChangeCharactersInRange:range replacementString:string];
            self.phoneLabel.text = resultString;
            
            return NO;
            break;
            
        case AGTextFieldEmail:
            [self scriptEmailField:textField shouldChangeCharactersInRange:range replacementString:string];
            self.emailLabel.text = resultString;
            
            return NO;
            
        default:
            break;
    }

    return YES;
}

#pragma mark- Methods

- (BOOL)scriptPhoneNumberField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {

    
    NSCharacterSet* validationSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    NSArray* components = [string componentsSeparatedByCharactersInSet:validationSet];
    
    if ([components count] > 1) {
        return NO;
    }
    
    NSString* newString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    
    //+XX (XXX) XXX-XXXX
    
    NSLog(@"new string = %@", newString);
    
    NSArray* validComponents = [newString componentsSeparatedByCharactersInSet:validationSet];
    
    newString = [validComponents componentsJoinedByString:@""];
    
    // XXXXXXXXXXXX
    
    NSLog(@"new string fixed = %@", newString);
    
    static const int localNumberMaxLength = 7;
    static const int areaCodeMaxLength = 3;
    static const int countryCodeMaxLength = 3;
    
    if ([newString length] > localNumberMaxLength + areaCodeMaxLength + countryCodeMaxLength) {
        return NO;
    }
    
    
    NSMutableString* resultString = [NSMutableString string];
    
    /*
     XXXXXXXXXXXX
     +XX (XXX) XXX-XXXX - local number
     */
    
    NSInteger localNumberLength = MIN([newString length], localNumberMaxLength);
    
    if (localNumberLength > 0) {
        
        NSString* number = [newString substringFromIndex:(int)[newString length] - localNumberLength];
        
        [resultString appendString:number];
        
        if ([resultString length] > 3) {
            [resultString insertString:@"-" atIndex:3];
        }
        
    }
    
    if ([newString length] > localNumberMaxLength) {
        
        NSInteger areaCodeLength = MIN((int)[newString length] - localNumberMaxLength, areaCodeMaxLength);
        
        NSRange areaRange = NSMakeRange((int)[newString length] - localNumberMaxLength - areaCodeLength, areaCodeLength);
        
        NSString* area = [newString substringWithRange:areaRange];
        
        area = [NSString stringWithFormat:@"(%@) ", area];
        
        [resultString insertString:area atIndex:0];
    }
    
    if ([newString length] > localNumberMaxLength + areaCodeMaxLength) {
        
        NSInteger countryCodeLength = MIN((int)[newString length] - localNumberMaxLength - areaCodeMaxLength, countryCodeMaxLength);
        
        NSRange countryCodeRange = NSMakeRange(0, countryCodeLength);
        
        NSString* countryCode = [newString substringWithRange:countryCodeRange];
        
        countryCode = [NSString stringWithFormat:@"+%@ ", countryCode];
        
        [resultString insertString:countryCode atIndex:0];
    }
    
    
    textField.text = resultString;
    return NO;
}

- (BOOL)scriptAgeField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    
    NSCharacterSet* validationSet = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    NSArray* components = [string componentsSeparatedByCharactersInSet:validationSet];
    
    if ([components count] > 1) {
        
        return NO;
        
    }
    
    NSString *resultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if ([resultString intValue] < 16) {
        
        textField.text = resultString;

        return NO;
        
        
        
    } else if ([resultString intValue] > 100) {
        
     
        return NO;
        
    } else {
        
        textField.text = resultString;
        
        
    }
    
    
    
    return NO;
}


- (BOOL)scriptEmailField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
       //соз набор символов
    
    NSCharacterSet* validation = [NSCharacterSet characterSetWithCharactersInString:@"!#$%^?&,<>""''()+-:;{}[]|/*//\\ "];
    
    NSArray* components = [string componentsSeparatedByCharactersInSet:validation];
    
    if ([components count] > 1) {
        return NO;
    }
    
    NSString* emailResultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    
    if (([emailResultString rangeOfString:@"@"].length < 1)) { //range -диапазон
        
        self.atPresent = NO; // BOOL значение
    }
    
    if ([emailResultString length] < 2 && [string isEqualToString:@"@"]) { //Если должны выполняться два и более условия, используется логический оператор И, представляемый двумя сиволами амперсанда &&.
        
        return NO; //не разрешаем ввод "@" первым символом (вводим после 2-го)
        
    }
    
    if (self.atPresent && [string isEqualToString:@"@"]) { // Ограничение на ввод "@" (можно только одну)
        return NO;
    }
   
    
    if ([string isEqualToString:@"@"]) {
        self.atPresent = YES;
    }
    
    if ([emailResultString length] > 30 ) { // до 30 символов в поле
        
        return NO;
        
    }

   
    
    textField.text = emailResultString; //вставляем в наш textField
    
    return NO;
}



- (BOOL)scriptNameField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{

    NSCharacterSet* validationName = [NSCharacterSet characterSetWithCharactersInString:@" @!#$%^?&,.<>""''()+-:;{}[]|/*//\\ 0123456789"];
    
    NSArray* componentsName = [string componentsSeparatedByCharactersInSet:validationName];
    
    if ([componentsName count] > 1) {
        return NO;
    }
    
    NSString* nameResultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if ([nameResultString length] > 15 ) { // до 15 символов
        
        return NO;
        
    }
    

     textField.text = nameResultString;
    
    return NO;
}


- (BOOL)scriptLastNameField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSCharacterSet* validationLastName = [NSCharacterSet characterSetWithCharactersInString:@" @!#$%^?&,.<>""''()+-:;{}[]|/*//\\ 0123456789"];
    
    NSArray* componentsLastname = [string componentsSeparatedByCharactersInSet:validationLastName];
    
    if ([componentsLastname count] > 1) {
        return NO;
    }
    
    NSString* lastNameResultString = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if ([lastNameResultString length] > 20 ) {
        
        return NO;
        
    }
    
    
    textField.text = lastNameResultString;
    
    return NO;
}


#pragma mark- Action

- (IBAction)actionMusic:(UISwitch *)sender {
    
    self.volumeSlider.enabled = sender.isOn;
    
    
}

- (IBAction)actionAutosave:(UISwitch *)sender {
    
  
    
}

- (IBAction)actionVolume:(UISlider *)sender {
    
    self.volumeLabel.text = [NSString stringWithFormat:@"%1.f",sender.value];
}


- (IBAction)actionGrefics:(UISegmentedControl *)sender {
    
    if (self.greficsSegmentedControl.selectedSegmentIndex == AGActionGreficsSegmentedControlLow ) {
        
        NSLog(@"Low grefics");
        
    }else if (self.greficsSegmentedControl.selectedSegmentIndex == AGActionGreficsSegmentedControlMiddle){
        
        NSLog(@"Middle grefics");
        
    }else {
        
        NSLog(@"High grefics");
        
    }

    
}

- (IBAction)actionBackground:(UISegmentedControl *)sender {
    
    if (self.backgroundSegmentedControl.selectedSegmentIndex == AGActionBackgroundSegmentedControlBlack) {
        NSLog(@"Black background");
    }else if (self.backgroundSegmentedControl.selectedSegmentIndex == AGActionBackgroundSegmentedControlWhite) {
        
        NSLog(@"White background");
        
    }else if (self.backgroundSegmentedControl.selectedSegmentIndex == AGActionBackgroundSegmentedControlGray) {
        
        NSLog(@"Gray background");
        
    }else {
        
        NSLog(@"Yellow background");
    }
}

#pragma mark- save and load 


- (void) saveSetting {

    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    
    //Save "Client info"
    [userDefaults setObject:self.firstNameField.text forKey:keyClientName];
    [userDefaults setObject:self.lastNameField.text forKey:keyClientLastName];
    [userDefaults setObject:self.loginField.text forKey:keyClientLogin];
    [userDefaults setObject:self.passwordField.text forKey:keyClientPassword];
    [userDefaults setObject:self.ageField.text forKey:keyClientAge];
    [userDefaults setObject:self.phoneField.text forKey:keyClientPhone];
    [userDefaults setObject:self.emailField.text forKey:keyClientEmail];
    
    //Save "Label"
    [userDefaults setObject:self.firstNameLabel.text forKey:keyClientName];
    [userDefaults setObject:self.lastNameLabel.text forKey:keyClientLastName];
    [userDefaults setObject:self.loginLabel.text forKey:keyClientLogin];
    [userDefaults setObject:self.passwordLabel.text forKey:keyClientPassword];
    [userDefaults setObject:self.ageLabel.text forKey:keyClientAge];
    [userDefaults setObject:self.phoneLabel.text forKey:keyClientPhone];
    [userDefaults setObject:self.emailLabel.text forKey:keyClientEmail];
 
    
    //Save "Interface"
    
    [userDefaults setInteger:self.greficsSegmentedControl.selectedSegmentIndex forKey:keyInterfaceGrefics];
    [userDefaults setBool:self.musicSwitch.isOn forKey:keyInterfaceMusic];
    [userDefaults setDouble:self.volumeSlider.value forKey:keyInterfaceVolume];
    [userDefaults setBool:self.autoSaveSwitch.isOn forKey:keyInterfaceAutosave];
    [userDefaults setInteger:self.backgroundSegmentedControl.selectedSegmentIndex forKey:keyInterfaceBackground];
    
    //Save "Label"
    
    self.volumeLabel.text = [NSString stringWithFormat:@"%1.f",self.volumeSlider.value];
    
   
    
    [userDefaults synchronize]; // если упадет приложение,то настройки все равно сохр.

}

- (void) loadSetting {
    
    NSUserDefaults* userDefaults = [NSUserDefaults standardUserDefaults];
    
    //Load "Client info"
    
    self.firstNameField.text = [userDefaults objectForKey:keyClientName];
    self.lastNameField.text  = [userDefaults objectForKey:keyClientLastName];
    self.loginField.text     = [userDefaults objectForKey:keyClientLogin];
    self.passwordField.text  = [userDefaults objectForKey:keyClientPassword];
    self.ageField.text       = [userDefaults objectForKey:keyClientAge];
    self.phoneField.text     = [userDefaults objectForKey:keyClientPhone];
    self.emailField.text     = [userDefaults objectForKey:keyClientEmail];
    
    //Load "Label"
    self.firstNameLabel.text = [userDefaults objectForKey:keyClientName];
    self.lastNameLabel.text  = [userDefaults objectForKey:keyClientLastName];
    self.loginLabel.text     = [userDefaults objectForKey:keyClientLogin];
    self.passwordLabel.text  = [userDefaults objectForKey:keyClientPassword];
    self.ageLabel.text       = [userDefaults objectForKey:keyClientAge];
    self.phoneLabel.text     = [userDefaults objectForKey:keyClientPhone];
    self.emailLabel.text     = [userDefaults objectForKey:keyClientEmail];
    
    //Load "Interface"
    
    self.greficsSegmentedControl.selectedSegmentIndex = [userDefaults integerForKey:keyInterfaceGrefics];
    self.musicSwitch.on = [userDefaults boolForKey:keyInterfaceMusic];
    self.volumeSlider.value = [userDefaults doubleForKey:keyInterfaceVolume];
    self.autoSaveSwitch.on = [userDefaults boolForKey:keyInterfaceAutosave];
    self.backgroundSegmentedControl.selectedSegmentIndex = [userDefaults integerForKey:keyInterfaceBackground];
    
     //Load "Label"
    
    self.volumeLabel.text = [NSString stringWithFormat:@"%1.f",self.volumeSlider.value];

}

- (IBAction)actionTextFieldChanged:(UITextField *)sender {
    
    [self saveSetting];
}

- (IBAction)actionValueChanged:(id)sender {
    
     [self saveSetting];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
